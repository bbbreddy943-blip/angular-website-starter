/** Change the site name and nav links here; the header and footer read from this file. */
export const SITE = {
  name: 'Northwind',
  nav: [
    { path: '/', label: 'Home', exact: true },
    { path: '/dashboard', label: 'Dashboard', exact: false },
    { path: '/todos', label: 'To-do', exact: false },
    { path: '/contact', label: 'Contact', exact: false },
  ],
};
