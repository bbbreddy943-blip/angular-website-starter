/** Shared sizing and scale helpers for the SVG charts. */
export const CHART_W = 600;
export const CHART_H = 260;
export const PAD = { top: 16, right: 16, bottom: 32, left: 44 };

export const INNER_W = CHART_W - PAD.left - PAD.right;
export const INNER_H = CHART_H - PAD.top - PAD.bottom;

/** Round a maximum value up to a "nice" number so axis ticks look clean. */
export function niceMax(value: number): number {
  if (value <= 0) return 1;
  const magnitude = Math.pow(10, Math.floor(Math.log10(value)));
  return Math.ceil(value / magnitude) * magnitude;
}

/** 12400 -> "12.4k" */
export function compact(value: number): string {
  return value >= 1000 ? `${Math.round(value / 100) / 10}k` : `${value}`;
}

/** Five evenly spaced horizontal grid lines (0%, 25% ... 100% of max). */
export function buildTicks(max: number): Array<{ y: number; label: string }> {
  return [0, 0.25, 0.5, 0.75, 1].map((t) => ({
    y: PAD.top + INNER_H - t * INNER_H,
    label: compact(max * t),
  }));
}
