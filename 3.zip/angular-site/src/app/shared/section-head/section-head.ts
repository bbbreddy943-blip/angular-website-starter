import { Component, input } from '@angular/core';

/** Small label + heading + optional intro paragraph used at the top of each section. */
@Component({
  selector: 'app-section-head',
  templateUrl: './section-head.html',
  styleUrl: './section-head.css',
})
export class SectionHead {
  readonly eyebrow = input.required<string>();
  readonly title = input.required<string>();
  readonly subtitle = input('');
}
