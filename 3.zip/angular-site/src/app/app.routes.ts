import { Routes } from '@angular/router';

import { Contact } from './pages/contact/contact';
import { Dashboard } from './pages/dashboard/dashboard';
import { Home } from './pages/home/home';
import { Todos } from './pages/todos/todos';

export const routes: Routes = [
  { path: '', component: Home, title: 'Home' },
  { path: 'dashboard', component: Dashboard, title: 'Dashboard' },
  { path: 'todos', component: Todos, title: 'To-do list' },
  { path: 'contact', component: Contact, title: 'Contact' },
  { path: '**', redirectTo: '' },
];
