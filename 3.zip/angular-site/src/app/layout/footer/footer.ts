import { Component } from '@angular/core';

import { SITE } from '../../site.config';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.html',
  styleUrl: './footer.css',
})
export class Footer {
  protected readonly siteName = SITE.name;
  protected readonly year = new Date().getFullYear();
}
