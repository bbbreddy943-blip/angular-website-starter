import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cta-banner',
  imports: [RouterLink],
  templateUrl: './cta-banner.html',
  styleUrl: './cta-banner.css',
})
export class CtaBanner {
  readonly title = input.required<string>();
  readonly text = input.required<string>();
  readonly buttonLabel = input.required<string>();
  readonly link = input('/contact');
}
