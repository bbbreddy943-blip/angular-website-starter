import { Component, input } from '@angular/core';

@Component({
  selector: 'app-project-card',
  templateUrl: './project-card.html',
  styleUrl: './project-card.css',
})
export class ProjectCard {
  readonly name = input.required<string>();
  readonly tag = input.required<string>();
  readonly text = input.required<string>();
  /** Color hue (0-360) for the thumbnail gradient. */
  readonly hue = input(250);
}
