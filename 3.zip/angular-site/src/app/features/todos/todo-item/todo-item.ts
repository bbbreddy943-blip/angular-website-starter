import { Component, input, output } from '@angular/core';

import { Todo } from '../../../models/todo';

/** One row of the list. Used on an <li> element: <li app-todo-item [todo]="t"></li> */
@Component({
  selector: 'li[app-todo-item]',
  templateUrl: './todo-item.html',
  styleUrl: './todo-item.css',
  host: { '[class.done]': 'todo().done' },
})
export class TodoItem {
  readonly todo = input.required<Todo>();
  readonly toggled = output<number>();
  readonly removed = output<number>();
}
