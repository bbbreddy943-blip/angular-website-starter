import { Component, input, output } from '@angular/core';

import { TodoFilter } from '../../../models/todo';

@Component({
  selector: 'app-todo-filter',
  templateUrl: './todo-filter.html',
  styleUrl: './todo-filter.css',
})
export class TodoFilterTabs {
  readonly active = input.required<TodoFilter>();
  readonly changed = output<TodoFilter>();

  protected readonly options: Array<{ key: TodoFilter; label: string }> = [
    { key: 'all', label: 'All' },
    { key: 'active', label: 'Active' },
    { key: 'done', label: 'Done' },
  ];
}
