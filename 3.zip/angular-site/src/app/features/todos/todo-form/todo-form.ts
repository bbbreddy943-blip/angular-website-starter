import { Component, output, signal } from '@angular/core';

@Component({
  selector: 'app-todo-form',
  templateUrl: './todo-form.html',
  styleUrl: './todo-form.css',
})
export class TodoForm {
  /** Emits the trimmed task title when the user submits. */
  readonly added = output<string>();

  protected readonly draft = signal('');

  protected onInput(event: Event): void {
    this.draft.set((event.target as HTMLInputElement).value);
  }

  protected submit(event: Event): void {
    event.preventDefault();
    const title = this.draft().trim();
    if (!title) return;
    this.added.emit(title);
    this.draft.set('');
  }
}
