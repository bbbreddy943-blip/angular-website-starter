import { Component, inject, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

type FieldName = 'name' | 'email' | 'topic' | 'message';

@Component({
  selector: 'app-contact-form',
  imports: [ReactiveFormsModule],
  templateUrl: './contact-form.html',
  styleUrl: './contact-form.css',
})
export class ContactForm {
  private readonly fb = inject(NonNullableFormBuilder);

  protected readonly topics = ['General question', 'New project', 'Support', 'Something else'];

  protected readonly form = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    topic: [this.topics[0], Validators.required],
    message: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(1000)]],
  });

  protected readonly sending = signal(false);
  protected readonly sent = signal(false);

  protected showError(name: FieldName): boolean {
    const control = this.form.controls[name];
    return control.invalid && (control.touched || control.dirty);
  }

  protected submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.sending.set(true);
    this.sent.set(false);

    // TODO: replace this timer with a real request once your backend exists, e.g.
    //   this.http.post('/api/contact', this.form.getRawValue()).subscribe(...)
    // (add provideHttpClient() to app.config.ts and inject HttpClient).
    console.log('Contact form submitted:', this.form.getRawValue());
    setTimeout(() => {
      this.sending.set(false);
      this.sent.set(true);
      this.form.reset({ topic: this.topics[0] });
    }, 700);
  }
}
