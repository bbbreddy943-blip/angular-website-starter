import { DecimalPipe } from '@angular/common';
import { Component, computed, input } from '@angular/core';

import { CHART_H, CHART_W, INNER_H, INNER_W, PAD, buildTicks, niceMax } from '../../../shared/chart-utils';

@Component({
  selector: 'app-line-chart',
  imports: [DecimalPipe],
  templateUrl: './line-chart.html',
  styleUrl: './line-chart.css',
})
export class LineChart {
  readonly title = input.required<string>();
  readonly labels = input.required<string[]>();
  readonly values = input.required<number[]>();
  /** Text shown after each value in the hover tooltip, e.g. " visitors". */
  readonly suffix = input('');

  protected readonly w = CHART_W;
  protected readonly h = CHART_H;
  protected readonly left = PAD.left;
  protected readonly right = CHART_W - PAD.right;

  private readonly max = computed(() => niceMax(Math.max(...this.values())));

  protected readonly ticks = computed(() => buildTicks(this.max()));

  protected readonly points = computed(() => {
    const values = this.values();
    const labels = this.labels();
    const max = this.max();
    const step = INNER_W / Math.max(values.length - 1, 1);
    return values.map((value, i) => ({
      label: labels[i],
      value,
      x: PAD.left + step * i,
      y: PAD.top + INNER_H - (value / max) * INNER_H,
    }));
  });

  protected readonly linePath = computed(() => this.points().map((p) => `${p.x},${p.y}`).join(' '));

  protected readonly areaPath = computed(() => {
    const pts = this.points();
    const baseline = CHART_H - PAD.bottom;
    return `${pts[0].x},${baseline} ${this.linePath()} ${pts[pts.length - 1].x},${baseline}`;
  });
}
