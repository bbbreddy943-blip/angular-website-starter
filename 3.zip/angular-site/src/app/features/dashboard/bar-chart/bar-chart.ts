import { DecimalPipe } from '@angular/common';
import { Component, computed, input } from '@angular/core';

import { CHART_H, CHART_W, INNER_H, INNER_W, PAD, buildTicks, niceMax } from '../../../shared/chart-utils';

@Component({
  selector: 'app-bar-chart',
  imports: [DecimalPipe],
  templateUrl: './bar-chart.html',
  styleUrl: './bar-chart.css',
})
export class BarChart {
  readonly title = input.required<string>();
  readonly labels = input.required<string[]>();
  readonly values = input.required<number[]>();
  /** Text shown before each value in the hover tooltip, e.g. "$". */
  readonly prefix = input('');

  protected readonly w = CHART_W;
  protected readonly h = CHART_H;
  protected readonly left = PAD.left;
  protected readonly right = CHART_W - PAD.right;

  private readonly max = computed(() => niceMax(Math.max(...this.values())));

  protected readonly ticks = computed(() => buildTicks(this.max()));

  protected readonly bars = computed(() => {
    const values = this.values();
    const labels = this.labels();
    const max = this.max();
    const slot = INNER_W / values.length;
    const width = slot * 0.62;

    return values.map((value, i) => {
      const height = (value / max) * INNER_H;
      return {
        label: labels[i],
        value,
        x: PAD.left + slot * i + (slot - width) / 2,
        y: PAD.top + INNER_H - height,
        width,
        height,
      };
    });
  });
}
