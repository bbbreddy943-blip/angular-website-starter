import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, computed, input, signal } from '@angular/core';

import { Order, OrderStatus } from '../../../models/order';

type SortKey = 'id' | 'customer' | 'date' | 'amount';

@Component({
  selector: 'app-orders-table',
  imports: [CurrencyPipe, DatePipe],
  templateUrl: './orders-table.html',
  styleUrl: './orders-table.css',
})
export class OrdersTable {
  readonly orders = input.required<Order[]>();

  protected readonly query = signal('');
  protected readonly statusFilter = signal<OrderStatus | 'All'>('All');
  protected readonly sortKey = signal<SortKey>('date');
  protected readonly sortDir = signal<'asc' | 'desc'>('desc');

  protected readonly statuses: Array<OrderStatus | 'All'> = ['All', 'Paid', 'Pending', 'Refunded'];

  protected readonly columns: Array<{ key: SortKey; label: string; numeric: boolean }> = [
    { key: 'id', label: 'Order', numeric: false },
    { key: 'customer', label: 'Customer', numeric: false },
    { key: 'date', label: 'Date', numeric: false },
    { key: 'amount', label: 'Amount', numeric: true },
  ];

  protected readonly rows = computed(() => {
    const q = this.query().trim().toLowerCase();
    const status = this.statusFilter();
    const key = this.sortKey();
    const dir = this.sortDir() === 'asc' ? 1 : -1;

    return this.orders()
      .filter(
        (o) =>
          (status === 'All' || o.status === status) &&
          (!q || `${o.id} ${o.customer}`.toLowerCase().includes(q)),
      )
      .sort((a, b) => {
        const av = a[key];
        const bv = b[key];
        const cmp =
          typeof av === 'number' && typeof bv === 'number'
            ? av - bv
            : String(av).localeCompare(String(bv));
        return cmp * dir;
      });
  });

  protected onSearch(event: Event): void {
    this.query.set((event.target as HTMLInputElement).value);
  }

  protected onStatus(event: Event): void {
    this.statusFilter.set((event.target as HTMLSelectElement).value as OrderStatus | 'All');
  }

  protected sortBy(key: SortKey): void {
    if (this.sortKey() === key) {
      this.sortDir.update((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      this.sortKey.set(key);
      this.sortDir.set('asc');
    }
  }

  protected indicator(key: SortKey): string {
    if (this.sortKey() !== key) return '';
    return this.sortDir() === 'asc' ? '▲' : '▼';
  }

  protected badgeClass(status: OrderStatus): string {
    return status === 'Paid' ? 'badge-success' : status === 'Pending' ? 'badge-warning' : 'badge-danger';
  }
}
