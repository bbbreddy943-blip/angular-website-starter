export type OrderStatus = 'Paid' | 'Pending' | 'Refunded';

export interface Order {
  id: string;
  customer: string;
  date: string; // ISO date, e.g. 2026-10-02
  amount: number;
  status: OrderStatus;
}
