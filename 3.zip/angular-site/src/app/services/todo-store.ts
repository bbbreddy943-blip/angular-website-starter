import { Injectable, computed, effect, signal } from '@angular/core';

import { Todo, TodoFilter } from '../models/todo';

const STORAGE_KEY = 'site.todos';

/** Holds the to-do list and saves it to the browser's localStorage. */
@Injectable({ providedIn: 'root' })
export class TodoStore {
  readonly todos = signal<Todo[]>(this.load());
  readonly filter = signal<TodoFilter>('all');

  readonly visible = computed(() => {
    const f = this.filter();
    return this.todos().filter((t) => (f === 'all' ? true : f === 'done' ? t.done : !t.done));
  });
  readonly remaining = computed(() => this.todos().filter((t) => !t.done).length);
  readonly completed = computed(() => this.todos().length - this.remaining());

  private nextId = Date.now();

  constructor() {
    effect(() => {
      const snapshot = JSON.stringify(this.todos());
      try {
        localStorage.setItem(STORAGE_KEY, snapshot);
      } catch {
        // Storage can be blocked (private mode); the list still works for this visit.
      }
    });
  }

  add(title: string): void {
    const clean = title.trim();
    if (!clean) return;
    this.todos.update((list) => [{ id: this.nextId++, title: clean, done: false }, ...list]);
  }

  toggle(id: number): void {
    this.todos.update((list) => list.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }

  remove(id: number): void {
    this.todos.update((list) => list.filter((t) => t.id !== id));
  }

  clearCompleted(): void {
    this.todos.update((list) => list.filter((t) => !t.done));
  }

  setFilter(filter: TodoFilter): void {
    this.filter.set(filter);
  }

  private load(): Todo[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw) as Todo[];
    } catch {
      // Fall through to the starter list.
    }
    return [
      { id: 1, title: 'Explore the dashboard', done: true },
      { id: 2, title: 'Add your own tasks here', done: false },
      { id: 3, title: 'Connect the contact form to a backend', done: false },
    ];
  }
}
