import { Injectable } from '@angular/core';

import { Order } from '../models/order';

/**
 * Sample data for the dashboard. Replace the arrays with HTTP calls
 * when you have a backend (see the README).
 */
@Injectable({ providedIn: 'root' })
export class DashboardData {
  readonly months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  readonly revenue = [12400, 15800, 14200, 18900, 21300, 19800, 24600, 27100, 25400, 29800, 31200, 35600];
  readonly visitors = [3200, 3600, 3400, 4100, 4800, 4500, 5200, 5900, 5600, 6400, 6900, 7800];

  readonly orders: Order[] = [
    { id: 'ORD-1001', customer: 'Ava Thompson', date: '2026-10-02', amount: 249.0, status: 'Paid' },
    { id: 'ORD-1002', customer: 'Liam Patel', date: '2026-10-03', amount: 89.5, status: 'Pending' },
    { id: 'ORD-1003', customer: 'Sofia Garcia', date: '2026-10-05', amount: 1299.0, status: 'Paid' },
    { id: 'ORD-1004', customer: 'Noah Kim', date: '2026-10-06', amount: 45.0, status: 'Refunded' },
    { id: 'ORD-1005', customer: 'Emma Wilson', date: '2026-10-08', amount: 532.25, status: 'Paid' },
    { id: 'ORD-1006', customer: 'Lucas Brown', date: '2026-10-09', amount: 78.9, status: 'Pending' },
    { id: 'ORD-1007', customer: 'Mia Johnson', date: '2026-10-11', amount: 910.0, status: 'Paid' },
    { id: 'ORD-1008', customer: 'Ethan Davis', date: '2026-10-12', amount: 150.0, status: 'Refunded' },
    { id: 'ORD-1009', customer: 'Isabella Martin', date: '2026-10-14', amount: 399.99, status: 'Paid' },
    { id: 'ORD-1010', customer: 'Oliver Lee', date: '2026-10-15', amount: 62.4, status: 'Pending' },
  ];
}
