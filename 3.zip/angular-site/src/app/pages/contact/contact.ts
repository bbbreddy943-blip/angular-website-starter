import { Component } from '@angular/core';

import { ContactForm } from '../../features/contact/contact-form/contact-form';
import { SectionHead } from '../../shared/section-head/section-head';

@Component({
  selector: 'app-contact',
  imports: [SectionHead, ContactForm],
  templateUrl: './contact.html',
  styleUrl: './contact.css',
})
export class Contact {}
