import { Component, inject } from '@angular/core';

import { TodoFilterTabs } from '../../features/todos/todo-filter/todo-filter';
import { TodoForm } from '../../features/todos/todo-form/todo-form';
import { TodoItem } from '../../features/todos/todo-item/todo-item';
import { TodoStore } from '../../services/todo-store';
import { SectionHead } from '../../shared/section-head/section-head';

@Component({
  selector: 'app-todos',
  imports: [SectionHead, TodoForm, TodoFilterTabs, TodoItem],
  templateUrl: './todos.html',
  styleUrl: './todos.css',
})
export class Todos {
  protected readonly store = inject(TodoStore);
}
