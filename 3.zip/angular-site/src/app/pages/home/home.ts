import { Component } from '@angular/core';

import { CtaBanner } from '../../features/home/cta-banner/cta-banner';
import { FeatureCard } from '../../features/home/feature-card/feature-card';
import { Hero } from '../../features/home/hero/hero';
import { ProjectCard } from '../../features/home/project-card/project-card';
import { SectionHead } from '../../shared/section-head/section-head';

@Component({
  selector: 'app-home',
  imports: [Hero, SectionHead, FeatureCard, ProjectCard, CtaBanner],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  protected readonly features = [
    { icon: '⚡', title: 'Fast by default', text: 'Standalone components and signals keep the app small and quick to render.' },
    { icon: '📱', title: 'Responsive', text: 'Layouts adapt from phones to wide desktop screens, with automatic dark mode.' },
    { icon: '🧩', title: 'Easy to extend', text: 'Every part is its own component, so adding sections or routes takes minutes.' },
  ];

  protected readonly projects = [
    { name: 'Analytics Suite', tag: 'Dashboard', text: 'Live charts and a sortable data table for tracking sales.', hue: 250 },
    { name: 'Task Planner', tag: 'Productivity', text: 'A to-do list that remembers your tasks between visits.', hue: 160 },
    { name: 'Client Portal', tag: 'Forms', text: 'Validated contact and onboarding forms with clear feedback.', hue: 20 },
  ];
}
