import { Component, inject } from '@angular/core';

import { BarChart } from '../../features/dashboard/bar-chart/bar-chart';
import { LineChart } from '../../features/dashboard/line-chart/line-chart';
import { OrdersTable } from '../../features/dashboard/orders-table/orders-table';
import { StatCard } from '../../features/dashboard/stat-card/stat-card';
import { DashboardData } from '../../services/dashboard-data';
import { SectionHead } from '../../shared/section-head/section-head';

const usd = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
const count = new Intl.NumberFormat('en-US');
const sum = (values: number[]) => values.reduce((total, v) => total + v, 0);

@Component({
  selector: 'app-dashboard',
  imports: [SectionHead, StatCard, BarChart, LineChart, OrdersTable],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {
  protected readonly data = inject(DashboardData);

  protected readonly stats = this.buildStats();

  private buildStats(): Array<{ label: string; value: string }> {
    const paid = this.data.orders.filter((o) => o.status === 'Paid').length;
    const paidRate = Math.round((paid / this.data.orders.length) * 100);
    return [
      { label: 'Revenue (year)', value: usd.format(sum(this.data.revenue)) },
      { label: 'Visitors (year)', value: count.format(sum(this.data.visitors)) },
      { label: 'Paid orders', value: String(paid) },
      { label: 'Paid rate', value: `${paidRate}%` },
    ];
  }
}
