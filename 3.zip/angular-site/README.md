# Angular website starter

A small website built with Angular standalone components and signals. It has four pages, and every
part of each page is its own component so you can learn how they fit together.

| Route        | Page                                                        |
| ------------ | ----------------------------------------------------------- |
| `/`          | Home: hero, feature cards, featured work, call to action    |
| `/dashboard` | Stat cards, bar and line charts, searchable orders table    |
| `/todos`     | To-do list that saves to the browser (localStorage)         |
| `/contact`   | Contact form with validation (demo submit, no backend yet)  |

## Project structure

```
src/
  styles.css                  Global design tokens (colors, spacing), buttons, cards, forms
  app/
    app.ts / app.html         Root component: header + page outlet + footer
    app.routes.ts             Which URL shows which page
    app.config.ts             App-wide providers (router)
    site.config.ts            Site name and nav links: edit this to rename the site

    layout/                   Parts on every page
      header/                   Logo, navigation, mobile menu
      footer/                   Copyright line

    pages/                    One component per route; each one assembles features
      home/  dashboard/  todos/  contact/

    features/                 Smaller components used by the pages
      home/                     hero, feature-card, project-card, cta-banner
      dashboard/                stat-card, bar-chart, line-chart, orders-table
      todos/                    todo-form, todo-filter, todo-item
      contact/                  contact-form

    shared/                   Reused everywhere
      section-head/             Label + heading + intro text
      chart-utils.ts            Sizing and scale helpers for the SVG charts

    services/                 Data and state
      dashboard-data.ts         Sample numbers and orders for the dashboard
      todo-store.ts             To-do list state + saving to localStorage

    models/                   TypeScript types (order.ts, todo.ts)
```

How the pieces talk to each other:
- A parent passes data **down** with `input()` (for example `<app-stat-card [label]="..." [value]="..." />`).
- A child sends events **up** with `output()` (for example `todo-form` emits `added`, and the page calls `store.add(...)`).
- Shared state lives in a service (`TodoStore`) that components get with `inject()`.

## Run it

This repository holds the `src/` folder only. Put it into a project made by the Angular CLI:

1. Install Node.js 20.19+ (or 22+), then the CLI:

   ```bash
   npm install -g @angular/cli
   ```

2. Create a project (accept the defaults for any other question):

   ```bash
   ng new my-site --routing --style=css --ssr=false
   cd my-site
   ```

3. Copy this repository's `src/` folder over the new project's `src/` folder, replacing files.
   Then delete the generated test file for the default welcome page:

   ```bash
   rm src/app/app.spec.ts
   ```

4. Start it and open http://localhost:4200:

   ```bash
   ng serve
   ```

5. Build for production with `ng build` (output goes to `dist/`).

These files use the naming from Angular 20 and newer (`app.ts`, class `App`). Use the latest CLI.

## Make it yours

- **Site name and menu:** `src/app/site.config.ts`
- **Colors and spacing:** the CSS variables at the top of `src/styles.css` (dark mode is automatic)
- **Home page text:** the `features` and `projects` lists in `src/app/pages/home/home.ts`
- **Dashboard numbers:** `src/app/services/dashboard-data.ts`
- **New page:** run `ng generate component pages/about`, add a route in `app.routes.ts`, and add a link in `site.config.ts`

## Connect a backend later

The contact form and dashboard use local data. To use a real API, add `provideHttpClient()` to
`app.config.ts`, inject `HttpClient` in a service, and replace the `TODO` in
`features/contact/contact-form/contact-form.ts` and the arrays in `services/dashboard-data.ts`.

## Learn Git with this project

1. Make a branch: `git checkout -b change-site-name`
2. Edit the name in `site.config.ts`, then `git add . && git commit -m "Rename site"`
3. Push it: `git push -u origin change-site-name`
4. On GitHub, open a pull request and merge it.
